<?
//apertura
genHeader("Ejemplo usando campos ocultos en formularios + POST");

//inicia variables
$datos = array();
initvars();

//carga posts recibidos desde formularios (usando campos ocultos)
cargaposts();

//reinicia variables a pedido del usuario
if ($_GET['reinicia'] == 'si') {
  initvars();
}

//procesa ingresos del usuario
if ($_POST['chkp1']) {
  $mensajes = procesap1();
}elseif ($_POST['chkp2']) {
  $mensajes = procesap2();
}

//muestra mensajes y errores, si existen
if ($mensajes) {
  muestramsg($mensajes);
}

//apertura de tabla principal
echo "<table width='75%' border='0' cellspacing='0' cellpadding='0' align='center' bgcolor='#DDDDFF'>
<tr><td>";

//selecciona pagina a mostrar
if ($datos['myname'] == '' or
    $datos['mymail'] == '') {
  pagina1();
}elseif ($datos['mysexo'] == 'Seleccione...' or
         $datos['myedad'] == '' or
		 $datos['myhobbie'] == '') {
  pagina2();
}else{
  pagina3();
}

//cierre de tabla principal
echo "<tr><td height=10></td></tr>";
echo "<tr><td>
<table width='100%' border='0' cellspacing='4' cellpadding='0'><tr><td height=30>
<b>Opciones:</b> <a href=$_SERVER[PHP_SELF]?reinicia=si>Limpiar todo y comenzar nuevamente</a>, 
<a href=http://www.nitrico.com.ar/>Ir a N�trico Sistemas</a></td></tr></table>\n";
echo "</td></tr></table>\n";

//cierre
genFooter('Versi�n 0.1.2 - Uso de campos ocultos en formularios + POST');
//********************************
function initvars() {
  global $datos;
  $datos['myname'] = '';
  $datos['mymail'] = '';
  $datos['mysexo'] = 'Seleccione...';
  $datos['myedad'] = '';
  $datos['myhobbie'] = '';
}
//********************************
function cargaposts() {
  global $datos;
  if ($_POST['myname']) {
    $datos['myname'] = $_POST['myname'];
  }
  if ($_POST['mymail']) {
    $datos['mymail'] = $_POST['mymail'];
  }
  if ($_POST['mysexo']) {
    $datos['mysexo'] = $_POST['mysexo'];
  }
  if ($_POST['myedad']) {
    $datos['myedad'] = $_POST['myedad'];
  }
  if ($_POST['myhobbie']) {
    $datos['myhobbie'] = $_POST['myhobbie'];
  }
}
//********************************
function procesap1() {
global $datos;
//array para mensajes
$mensajes = array();
//nombre
if ($_POST['newname']) {
   //cargar
   $datos['myname'] = $_POST['newname'];
  }else{
   $mensajes[] = "ERROR! - Debe ingresar un nombre...";
   $datos['myname'] = '';
}
//mail
if ($_POST['newmail']) {
   //validar
   if (! preg_match('/^[^@\s]+@([-a-z0-9]+\.)+[a-z]{2,}$/i',$_POST['newmail'])) {
     $mensajes[] = "ERROR! - El mail no es v�lido, ingreselo nuevamente...";
   }else{
     $datos['mymail'] = $_POST['newmail'];
   }
  }else{
   $mensajes[] = "ERROR! - Debe ingresar un mail...";
   $datos['mymail'] = '';
}
return $mensajes;
}
//********************************
function procesap2() {
global $datos;
//array para mensajes
$mensajes = array();
//sexo
if ($_POST['newsexo']=="Seleccione...") {
   $mensajes[] = "ERROR! - Debe ingresar datos de sexo...";
   $datos['mysexo'] = "Seleccione...";
  }else{
   //cargar
   $datos['mysexo'] = $_POST['newsexo'];
}
//edad
if ($_POST['newedad']) {
   //cargar
   $datos['myedad'] = $_POST['newedad'];
  }else{
   $mensajes[] = "ERROR! - Debe ingresar datos de edad...";
   $datos['myedad'] = '';
}
//hobbie
if ($_POST['newhobbie']) {
   //cargar
   $datos['myhobbie'] = $_POST['newhobbie'];
  }else{
   $mensajes[] = "ERROR! - Debe ingresar datos de hobbie � deporte favorito...";
   $datos['myhobbie'] = '';
}
return $mensajes;
}
//********************************
function muestramsg($mensajes) {
  //apertura de tabla interior
  echo "<table width='75%' border='0' cellspacing='0' cellpadding='0' align='center'>";
  echo "<tr><td><font color=#FF0000><b>";
  echo implode("</br>",$mensajes);
  echo "</b></font></td></tr>";
  //cierre de tabla interior
  echo "</table>\n";
}
//********************************
function pagina1() {
  global $datos;

  //apertura de tabla interior
  echo "<table width='100%' border='0' cellspacing='4' cellpadding='0'>";
  echo "<tr><td width='30%'></td><td width='70%'></td></tr>";

  //pedir mail
  echo "
  <form method=post action=$_SERVER[PHP_SELF]>
  <tr><td colspan=2><b>PAGINA 1</b></td></tr>
  <tr><td colspan=2><b>DATOS PERSONALES</b></td></tr>
  <tr><td>Nombre:</td><td><input type=text name=newname value='$datos[myname]' size=50 maxlength=50></td></tr>
  <tr><td>Mail:</td><td><input type=text name=newmail value='$datos[mymail]' size=50 maxlength=50></td></tr>
  <tr><td colspan=2><i>Por favor, ingrese los datos solicitados y haga clic en 'Siguiente'. Todos los campos son obligatorios.</i></td></tr>
  <input type=hidden name=chkp1 value=1>
  <tr><td><input type=submit value='Siguiente >>'></td><td></td></tr>
  </form>";

  //cierre de tabla interior
  echo "</table>\n";
}
//********************************
function pagina2() {
  global $datos;
  
  //apertura de tabla interior
  echo "<table width='100%' border='0' cellspacing='4' cellpadding='0'>";
  echo "<tr><td width='30%'></td><td width='70%'></td></tr>";

  //encabezado
  echo "<tr><td colspan=2><b>PAGINA 2</b></td></tr>";
  echo "<tr><td colspan=2><b>DATOS PERSONALES</b></td></tr>";
  echo "<tr><td>Nombre:</td><td><b>$datos[myname]</b></td></tr>";
  echo "<tr><td>Mail:</td><td><b>$datos[mymail]</b></td></tr>";

  //pide mas datos
  echo "<tr><td colspan=2><b>MAS INFORMACION</b></td></tr>";
  echo "
  <form method=post action=$_SERVER[PHP_SELF]>
  <tr><td valign='top'>Sexo:</td><td>
  <select name=newsexo>
  <option>Seleccione...
  <option>Masculino
  <option>Femenino
  </select>
  </td></tr>
  <tr><td valign='top'>Edad:</td><td>
  <select name=newedad size=5>
    <option>0 a 20 a�os</option>
    <option>21 a 40 a�os</option>
    <option>41 a 60 a�os</option>
    <option>61 a 80 a�os</option>
    <option>81 � + a�os</option>
  </select>
  </td></tr>
  <tr><td>Hobbie � deporte </br>favorito:</td>
  <td><input type=text name=newhobbie value='$datos[myhobbie]' size=50 maxlength=50></td></tr>
  <tr><td colspan=2><i>Por favor, ingrese los datos solicitados y haga clic en 'Siguiente'. Todos los campos son obligatorios.</i></td></tr>
  <input type=hidden name=chkp2 value=1>
  <input type=hidden name=myname value='$datos[myname]'>
  <input type=hidden name=mymail value='$datos[mymail]'>
  <tr><td><input type=submit value='Siguiente >>'></td><td></td></tr>
  </form>";

  //cierre de tabla interior
  echo "</table>\n";
}
//********************************
function pagina3() {
  global $datos;
  
  //apertura de tabla interior
  echo "<table width='100%' border='0' cellspacing='4' cellpadding='0'>";
  echo "<tr><td width='30%'></td><td width='70%'></td></tr>";

  //encabezado
  echo "<tr><td colspan=2><b>PAGINA 3</b></td></tr>";
  echo "<tr><td><b>DATOS PERSONALES</b></td><td><i>(cargados en p�gina 1)</i></td></tr>";
  echo "<tr><td>Nombre:</td><td><b>$datos[myname]</b></td></tr>";
  echo "<tr><td>Mail:</td><td><b>$datos[mymail]</b></td></tr>";

  //mas info
  echo "<tr><td><b>MAS INFORMACION</b></td><td><i>(cargados en p�gina 2)</i></td></tr>";
  echo "<tr><td>Sexo:</td><td><b>$datos[mysexo]</b></td></tr>";
  echo "<tr><td>Edad:</td><td><b>$datos[myedad]</b></td></tr>";
  echo "<tr><td>Hobbie:</td><td><b>$datos[myhobbie]</b></td></tr>";
  //cierre de tabla interior
  echo "</table>\n";
}
//********************************
function genHeader( $title )
{
echo "<!--AUTOR: ROMAN A. MUSSI-->
<html>
<head>
<title>$title</title>
<style type=\"text/css\">
<!--
	body, table { font-family: Arial; font-size: 10pt; line-height: 1.5 }
-->
</style>
</head>
<body bgcolor=#FFFFFF>";
//titulo
echo "<center><b>PERSISTENCIA DE DATOS CON PHP</br>
$title</b></center>";
}
//********************************
function genFooter( $version )
{
echo "
<table align=center width='75%' border='0' cellspacing='0' cellpadding='0'>
<tr><td height=1 bgcolor=#CCCCCC></td></tr>
<tr><td align=center><small>Ejemplos de persistencia de datos con PHP</br>
$version</br>
(c) N�trico Sistemas, Derechos Reservados.</br>
Desarrollado por: Rom�n A. Mussi</small>
</td></tr>
</table>
</body>
</html>";
exit;
}
//********************************
?>